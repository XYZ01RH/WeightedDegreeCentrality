To compile in the command line cd to the src folder of this Project, type the following then hit enter:
javac UndirectedGraph.java

To run it, include arguments for the input textfile followed by the enter key:
java UndirectedGraph.java graph.txt

The output is already there to provide a sample, but if you change the contents of the input file (graph.txt), then the output,
wdegree.txt will update accordingly.

Answers to problems 1-4 are included in the zip file and titled HW1HansonRiley.pdf
